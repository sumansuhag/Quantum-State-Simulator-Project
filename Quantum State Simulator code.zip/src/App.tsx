import { useState, useEffect, useRef } from "react";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "../components/ui/card";
import { BlochSphere } from "../components/BlochSphere";
import { ControlsPanel } from "../components/ControlsPanel";
import { StateDisplay } from "../components/StateDisplay";
import { QuantumState, initializeState, evolveState, SimulationParams } from "../utils/quantum";

function App() {
  const [state, setState] = useState<QuantumState>(() => initializeState(Math.PI / 4, 0));
  const [isRunning, setIsRunning] = useState(false);
  const [energyDifference, setEnergyDifference] = useState(1);
  const [decoherenceRate, setDecoherenceRate] = useState(0.1);
  const [includeEnvironment, setIncludeEnvironment] = useState(false);
  
  const animationRef = useRef<number>();
  const lastTimeRef = useRef<number>(0);
  
  const params: SimulationParams = {
    energyDifference,
    decoherenceRate,
    includeEnvironment,
    time: 0
  };
  
  useEffect(() => {
    if (!isRunning) {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
      return;
    }
    
    const animate = (timestamp: number) => {
      if (!lastTimeRef.current) {
        lastTimeRef.current = timestamp;
      }
      
      const deltaTime = (timestamp - lastTimeRef.current) / 1000; // Convert to seconds
      lastTimeRef.current = timestamp;
      
      setState(prevState => evolveState(prevState, params, deltaTime));
      animationRef.current = requestAnimationFrame(animate);
    };
    
    animationRef.current = requestAnimationFrame(animate);
    
    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
      }
    };
  }, [isRunning, params]);
  
  const handleTogglePlay = () => {
    setIsRunning(!isRunning);
    lastTimeRef.current = 0;
  };
  
  const handleReset = () => {
    setIsRunning(false);
    lastTimeRef.current = 0;
    setState(initializeState(Math.PI / 4, 0));
  };
  
  const handleEnergyChange = (value: number) => {
    setEnergyDifference(value);
  };
  
  const handleDecoherenceChange = (value: number) => {
    setDecoherenceRate(value);
  };
  
  const handleEnvironmentToggle = (checked: boolean) => {
    setIncludeEnvironment(checked);
    if (!checked) {
      // Reset coherence when environment is disabled
      setState(prev => ({ ...prev, coherence: 1 }));
    }
  };
  
  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-4 md:p-8">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <div className="mb-8 text-center">
          <h1 className="text-4xl font-bold text-slate-800 mb-2">
            Quantum State Simulator
          </h1>
          <p className="text-slate-600 max-w-2xl mx-auto">
            Visualize qubit dephasing and decoherence on the Bloch sphere. 
            Watch how quantum information evolves over time and is lost to the environment.
          </p>
        </div>
        
        {/* Main content */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
          {/* Left panel - Controls */}
          <div className="lg:col-span-1">
            <ControlsPanel
              isRunning={isRunning}
              onTogglePlay={handleTogglePlay}
              onReset={handleReset}
              energyDifference={energyDifference}
              onEnergyChange={handleEnergyChange}
              decoherenceRate={decoherenceRate}
              onDecoherenceChange={handleDecoherenceChange}
              includeEnvironment={includeEnvironment}
              onEnvironmentToggle={handleEnvironmentToggle}
            />
          </div>
          
          {/* Center - Bloch Sphere */}
          <div className="lg:col-span-1">
            <Card className="bg-white border-slate-200 shadow-sm">
              <CardHeader>
                <CardTitle className="text-lg text-slate-800">Bloch Sphere</CardTitle>
                <CardDescription className="text-slate-600">
                  Real-time visualization of qubit state
                </CardDescription>
              </CardHeader>
              <CardContent>
                <BlochSphere
                  theta={state.theta}
                  phi={state.phi}
                  coherence={state.coherence}
                />
              </CardContent>
            </Card>
          </div>
          
          {/* Right panel - State display */}
          <div className="lg:col-span-1">
            <StateDisplay state={state} />
          </div>
        </div>
        
        {/* Info cards */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mt-6">
          <Card className="bg-white border-slate-200 shadow-sm">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Dephasing</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-600">
                Energy difference ΔE causes the relative phase between |0⟩ and |1⟩ to evolve over time.
                The state vector rotates around the vertical axis of the Bloch sphere.
              </p>
            </CardContent>
          </Card>
          
          <Card className="bg-white border-slate-200 shadow-sm">
            <CardHeader>
              <CardTitle className="text-base font-semibold text-slate-800">Decoherence</CardTitle>
            </CardHeader>
            <CardContent>
              <p className="text-sm text-slate-600">
                When coupled to the environment, quantum information is lost. The state vector 
                shrinks toward the center, representing a transition from pure to mixed state.
              </p>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}

export default App;