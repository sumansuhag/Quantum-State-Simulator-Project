import { sphericalToCartesian } from "../utils/quantum";

interface BlochSphereProps {
  theta: number;
  phi: number;
  coherence: number;
}

export function BlochSphere({ theta, phi, coherence }: BlochSphereProps) {
  const size = 300;
  const center = size / 2;
  const radius = size * 0.4;
  
  // Calculate state vector position with coherence scaling
  const effectiveRadius = radius * coherence;
  const pos = sphericalToCartesian(theta, phi, effectiveRadius);
  
  // Project 3D to 2D (simple orthographic projection)
  const x2d = center + pos.x;
  const y2d = center - pos.y; // Flip Y for SVG coordinates
  
  // Calculate arrow end point
  const arrowLength = 20;
  const angle = Math.atan2(-pos.y, pos.x);
  const arrowX1 = x2d - arrowLength * Math.cos(angle - Math.PI / 6);
  const arrowY1 = y2d + arrowLength * Math.sin(angle - Math.PI / 6);
  const arrowX2 = x2d - arrowLength * Math.cos(angle + Math.PI / 6);
  const arrowY2 = y2d + arrowLength * Math.sin(angle + Math.PI / 6);
  
  // Equator ellipse for 3D effect
  const equatorRx = radius;
  const equatorRy = radius * 0.3;
  
  return (
    <div className="flex items-center justify-center">
      <svg width={size} height={size} className="drop-shadow-lg">
        {/* Background circle */}
        <circle
          cx={center}
          cy={center}
          r={radius}
          fill="none"
          stroke="currentColor"
          strokeWidth="2"
          className="text-slate-300"
        />
        
        {/* Equator (ellipse for 3D effect) */}
        <ellipse
          cx={center}
          cy={center}
          rx={equatorRx}
          ry={equatorRy}
          fill="none"
          stroke="currentColor"
          strokeWidth="1"
          className="text-slate-400"
          strokeDasharray="4 4"
        />
        
        {/* Vertical axis line */}
        <line
          x1={center}
          y1={center - radius}
          x2={center}
          y2={center + radius}
          stroke="currentColor"
          strokeWidth="1"
          className="text-slate-400"
        />
        
        {/* Horizontal axis line */}
        <line
          x1={center - radius}
          y1={center}
          x2={center + radius}
          y2={center}
          stroke="currentColor"
          strokeWidth="1"
          className="text-slate-400"
        />
        
        {/* |0⟩ label (top) */}
        <text x={center} y={center - radius - 10} textAnchor="middle" className="fill-blue-600 text-sm font-semibold">
          |0⟩
        </text>
        
        {/* |1⟩ label (bottom) */}
        <text x={center} y={center + radius + 20} textAnchor="middle" className="fill-red-600 text-sm font-semibold">
          |1⟩
        </text>
        
        {/* |+⟩ label (right) */}
        <text x={center + radius + 15} y={center + 5} textAnchor="middle" className="fill-emerald-600 text-sm font-semibold">
          |+⟩
        </text>
        
        {/* |-⟩ label (left) */}
        <text x={center - radius - 15} y={center + 5} textAnchor="middle" className="fill-amber-600 text-sm font-semibold">
          |-⟩
        </text>
        
        {/* State vector line */}
        <line
          x1={center}
          y1={center}
          x2={x2d}
          y2={y2d}
          stroke="currentColor"
          strokeWidth="3"
          className="text-violet-600"
          strokeLinecap="round"
        />
        
        {/* Arrow head */}
        <polygon
          points={`${x2d},${y2d} ${arrowX1},${arrowY1} ${arrowX2},${arrowY2}`}
          fill="currentColor"
          className="text-violet-600"
        />
        
        {/* Coherence indicator circle at origin */}
        {coherence < 1 && (
          <circle
            cx={center}
            cy={center}
            r={radius * (1 - coherence) * 0.5}
            fill="currentColor"
            className="text-slate-200 opacity-50"
          />
        )}
      </svg>
    </div>
  );
}