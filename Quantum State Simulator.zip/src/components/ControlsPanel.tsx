import { Label } from "../components/ui/label";
import { Slider } from "../components/ui/slider";
import { Button } from "../components/ui/button";
import { Switch } from "../components/ui/switch";
import { Play, Pause, RotateCcw } from "lucide-react";

interface ControlsPanelProps {
  isRunning: boolean;
  onTogglePlay: () => void;
  onReset: () => void;
  energyDifference: number;
  onEnergyChange: (value: number) => void;
  decoherenceRate: number;
  onDecoherenceChange: (value: number) => void;
  includeEnvironment: boolean;
  onEnvironmentToggle: (checked: boolean) => void;
}

export function ControlsPanel({
  isRunning,
  onTogglePlay,
  onReset,
  energyDifference,
  onEnergyChange,
  decoherenceRate,
  onDecoherenceChange,
  includeEnvironment,
  onEnvironmentToggle
}: ControlsPanelProps) {
  return (
    <div className="space-y-6 p-6 bg-white rounded-xl border border-slate-200 shadow-sm">
      <div className="flex items-center justify-between">
        <h3 className="text-lg font-semibold text-slate-800">Simulation Controls</h3>
        <div className="flex gap-2">
          <Button
            onClick={onTogglePlay}
            variant={isRunning ? "default" : "outline"}
            size="sm"
          >
            {isRunning ? <Pause className="w-4 h-4 mr-2" /> : <Play className="w-4 h-4 mr-2" />}
            {isRunning ? "Pause" : "Start"}
          </Button>
          <Button onClick={onReset} variant="outline" size="sm">
            <RotateCcw className="w-4 h-4 mr-2" />
            Reset
          </Button>
        </div>
      </div>
      
      <div className="space-y-4">
        <div className="flex items-center justify-between">
          <Label htmlFor="environment" className="text-slate-700 font-medium">
            Include Environment
          </Label>
          <Switch
            id="environment"
            checked={includeEnvironment}
            onCheckedChange={onEnvironmentToggle}
          />
        </div>
        <p className="text-xs text-slate-500">
          When enabled, the qubit couples to the environment causing decoherence.
        </p>
      </div>
      
      <div className="space-y-3">
        <div className="flex justify-between">
          <Label className="text-slate-700 font-medium">Energy Difference (ΔE)</Label>
          <span className="text-sm text-slate-600 font-mono">{energyDifference.toFixed(2)} rad/s</span>
        </div>
        <Slider
          value={[energyDifference]}
          onValueChange={(values) => onEnergyChange(values[0])}
          min={0}
          max={5}
          step={0.1}
          className="w-full"
        />
        <p className="text-xs text-slate-500">
          Controls the rate of phase evolution (dephasing).
        </p>
      </div>
      
      <div className="space-y-3">
        <div className="flex justify-between">
          <Label className="text-slate-700 font-medium">Decoherence Rate</Label>
          <span className="text-sm text-slate-600 font-mono">{(decoherenceRate * 100).toFixed(0)}%</span>
        </div>
        <Slider
          value={[decoherenceRate]}
          onValueChange={(values) => onDecoherenceChange(values[0])}
          min={0}
          max={1}
          step={0.01}
          className="w-full"
          disabled={!includeEnvironment}
        />
        <p className="text-xs text-slate-500">
          {includeEnvironment 
            ? "Rate at which quantum information is lost to the environment."
            : "Enable environment to adjust decoherence rate."}
        </p>
      </div>
    </div>
  );
}