import { Card, CardContent, CardHeader, CardTitle } from "../components/ui/card";
import { QuantumState } from "../utils/quantum";
import { formatComplex, getMeasurementProbabilities } from "../utils/quantum";

interface StateDisplayProps {
  state: QuantumState;
}

export function StateDisplay({ state }: StateDisplayProps) {
  const probs = getMeasurementProbabilities(state);
  const phaseDegrees = ((state.phi % (2 * Math.PI)) * 180 / Math.PI + 360) % 360;
  const coherencePercent = state.coherence * 100;
  
  return (
    <Card className="bg-white border-slate-200 shadow-sm">
      <CardHeader>
        <CardTitle className="text-lg text-slate-800">Quantum State</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        {/* State vector equation */}
        <div className="p-4 bg-slate-50 rounded-lg border border-slate-200">
          <div className="text-center font-mono text-sm text-slate-700">
            <span className="text-blue-600">|ψ⟩</span>
            <span className="mx-2">=</span>
            <span className="text-violet-600">{formatComplex(state.alpha)}</span>
            <span className="text-blue-600 mx-1">|0⟩</span>
            <span className="mx-1">+</span>
            <span className="text-violet-600">{formatComplex(state.beta)}</span>
            <span className="text-red-600 mx-1">|1⟩</span>
          </div>
        </div>
        
        {/* Phase angle */}
        <div className="flex justify-between items-center">
          <span className="text-sm text-slate-600">Phase (φ)</span>
          <span className="font-mono text-sm font-semibold text-slate-800">
            {phaseDegrees.toFixed(1)}°
          </span>
        </div>
        
        {/* Coherence */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <span className="text-sm text-slate-600">Coherence</span>
            <span className={`font-mono text-sm font-semibold ${
              coherencePercent > 70 ? "text-emerald-600" : 
              coherencePercent > 30 ? "text-amber-600" : "text-red-600"
            }`}>
              {coherencePercent.toFixed(1)}%
            </span>
          </div>
          <div className="w-full bg-slate-200 rounded-full h-2">
            <div
              className={`h-2 rounded-full transition-all duration-300 ${
                coherencePercent > 70 ? "bg-emerald-500" : 
                coherencePercent > 30 ? "bg-amber-500" : "bg-red-500"
              }`}
              style={{ width: `${coherencePercent}%` }}
            />
          </div>
        </div>
        
        {/* Measurement probabilities */}
        <div className="pt-2 border-t border-slate-200">
          <div className="space-y-2">
            <div className="flex justify-between items-center">
              <span className="text-sm text-slate-600">P(|0⟩)</span>
              <span className="font-mono text-sm text-blue-600 font-semibold">
                {(probs.prob0 * 100).toFixed(1)}%
              </span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2">
              <div
                className="bg-blue-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${probs.prob0 * 100}%` }}
              />
            </div>
            
            <div className="flex justify-between items-center pt-1">
              <span className="text-sm text-slate-600">P(|1⟩)</span>
              <span className="font-mono text-sm text-red-600 font-semibold">
                {(probs.prob1 * 100).toFixed(1)}%
              </span>
            </div>
            <div className="w-full bg-slate-200 rounded-full h-2">
              <div
                className="bg-red-500 h-2 rounded-full transition-all duration-300"
                style={{ width: `${probs.prob1 * 100}%` }}
              />
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}