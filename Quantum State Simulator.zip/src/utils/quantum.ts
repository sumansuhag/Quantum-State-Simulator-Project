// Quantum state utilities for the simulator

export interface QuantumState {
  alpha: { real: number; imag: number };
  beta: { real: number; imag: number };
  theta: number;    // Polar angle (0 to π)
  phi: number;      // Azimuthal angle (0 to 2π)
  coherence: number; // 0 to 1, represents purity of state
}

export interface SimulationParams {
  energyDifference: number; // ΔE in rad/s
  decoherenceRate: number;  // 0 to 1
  includeEnvironment: boolean;
  time: number;
}

// Initialize qubit in superposition state
export function initializeState(theta: number = Math.PI / 4, phi: number = 0): QuantumState {
  const alphaReal = Math.cos(theta / 2);
  const betaReal = Math.sin(theta / 2);
  
  return {
    alpha: { real: alphaReal, imag: 0 },
    beta: { real: betaReal * Math.cos(phi), imag: betaReal * Math.sin(phi) },
    theta,
    phi,
    coherence: 1
  };
}

// Evolve state over time with phase drift
export function evolveState(
  state: QuantumState,
  params: SimulationParams,
  deltaTime: number
): QuantumState {
  const { energyDifference, decoherenceRate, includeEnvironment } = params;
  
  // Phase evolution: φ(t) = φ₀ + ΔE·t
  const newPhi = state.phi + energyDifference * deltaTime;
  
  // Apply decoherence if environment is included
  let newCoherence = state.coherence;
  if (includeEnvironment) {
    // Exponential decay of coherence: C(t) = C₀ * e^(-γt)
    const decayFactor = Math.exp(-decoherenceRate * deltaTime);
    newCoherence = state.coherence * decayFactor;
    
    // Add random phase kicks when decohering
    if (decoherenceRate > 0) {
      const phaseNoise = (Math.random() - 0.5) * decoherenceRate * 0.5;
      return {
        ...state,
        phi: newPhi + phaseNoise,
        coherence: newCoherence
      };
    }
  }
  
  return {
    ...state,
    phi: newPhi,
    coherence: newCoherence
  };
}

// Convert spherical coordinates to Cartesian for 3D visualization
export function sphericalToCartesian(theta: number, phi: number, radius: number = 1) {
  return {
    x: radius * Math.sin(theta) * Math.cos(phi),
    y: radius * Math.cos(theta),
    z: radius * Math.sin(theta) * Math.sin(phi)
  };
}

// Calculate probability of measuring |0⟩ or |1⟩
export function getMeasurementProbabilities(state: QuantumState) {
  const effectiveRadius = state.coherence;
  const prob0 = Math.pow(Math.cos(state.theta / 2), 2);
  const prob1 = Math.pow(Math.sin(state.theta / 2), 2);
  
  // When decohered, probabilities approach 50/50
  const mixedness = 1 - state.coherence;
  return {
    prob0: prob0 * effectiveRadius + mixedness * 0.5,
    prob1: prob1 * effectiveRadius + mixedness * 0.5
  };
}

// Format complex number for display
export function formatComplex(c: { real: number; imag: number }): string {
  const sign = c.imag >= 0 ? '+' : '-';
  const absImag = Math.abs(c.imag);
  if (Math.abs(c.imag) < 0.001) return c.real.toFixed(3);
  if (Math.abs(c.real) < 0.001) return `${absImag.toFixed(3)}i`;
  return `${c.real.toFixed(3)} ${sign} ${absImag.toFixed(3)}i`;
}